package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class services {
	@Autowired
	repository repo;
	
	public List<details> getAlldonors() {
		// TODO Auto-generated method stub
		ArrayList<details> allDonors=new ArrayList<>();
		 repo.findAll().forEach(allDonors::add);
	     return allDonors;
	}
	
	public void addDonor(details det) {
		// TODO Auto-generated method stub
		repo.save(det);
	}
}
