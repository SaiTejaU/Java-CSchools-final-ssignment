package com.example.demo;

import javax.persistence.*;

@Entity
class details
{
	@Id
	@Column
	String mail;
	@Column
	String name;
	@Column
	String contact;
	@Column
	String type;
	public details()
	{
	}
	public details(String mail, String name, String contact, String type) {
		super();
		this.mail = mail;
		this.name = name;
		this.contact = contact;
		this.type = type;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}