import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(public http:HttpClient) { }

  type=["-select-","A+","A-","B+","B-","AB+","AB-","O+","O-","Bombay group"];

  var_name=""
  var_mail=""
  var_type=""
  var_cont=""
  var_state=""
  var_dist=""
  var_city=""
  status=["-select-","Yes","No"];
  var_status=""
  ngOnInit(): void {
  }
register()
{
  var det={
    "mail":this.var_mail,
    "name":this.var_name,
    "contact":this.var_cont,
    "type":this.var_type,
  }
  this.http.post<any>("http://localhost:8080/donors",det)
  alert(JSON.stringify(det));
}
}
